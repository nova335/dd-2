require('dotenv').config();
const fs = require('fs');
const path = require('path');
const {
  Client,
  GatewayIntentBits,
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  SlashCommandBuilder,
  PermissionFlagsBits,
  InteractionContextType,
  ChannelType,
  REST,
  Routes,
  MessageFlags,
} = require('discord.js');

const TOKEN = process.env.DISCORD_TOKEN;
const CLIENT_ID = process.env.CLIENT_ID;
const GUILD_ID = process.env.GUILD_ID;
const CURRENCY = process.env.CURRENCY_NAME || '원';
const MIN_CHARGE = Number(process.env.MIN_CHARGE || 1000);
const MAX_CHARGE = 10_000_000;
const MAX_PENDING = 3; // 한 사람이 동시에 올릴 수 있는 충전 요청 수

if (!TOKEN || !CLIENT_ID) {
  console.error('❌ .env 에 DISCORD_TOKEN, CLIENT_ID 를 설정해주세요.');
  process.exit(1);
}

/* ------------------------------ 데이터 저장 ------------------------------ */
const DB_PATH = path.join(__dirname, 'data.json');
const TMP_PATH = DB_PATH + '.tmp';

function load() {
  try {
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
  } catch {
    return {};
  }
}
const db = Object.assign(
  { users: {}, items: {}, charges: {}, settings: {}, nextId: 1, nextChargeId: 1 },
  load(),
);

function save() {
  fs.writeFileSync(TMP_PATH, JSON.stringify(db, null, 2));
  fs.renameSync(TMP_PATH, DB_PATH);
}

function getUser(id) {
  if (!db.users[id]) db.users[id] = { balance: 0, totalSpent: 0, totalCharged: 0, history: [] };
  return db.users[id];
}

const fmt = (n) => Number(n).toLocaleString('ko-KR');
const money = (n) => `${fmt(n)}${CURRENCY}`;
const remaining = (item) => (item.type === 'role' ? Infinity : item.lines.length);
const stockText = (item) => {
  if (item.type === 'role') return '무제한';
  return item.lines.length === 0 ? '품절' : `${item.lines.length}개`;
};
const EPHEMERAL = MessageFlags.Ephemeral;

/* ------------------------------ 명령어 정의 ------------------------------ */
const ADMIN = PermissionFlagsBits.ManageGuild;
const admin = (b) => b.setDefaultMemberPermissions(ADMIN).setContexts(InteractionContextType.Guild);

const commands = [
  new SlashCommandBuilder()
    .setName('내정보')
    .setDescription('내 잔액과 구매 현황을 봐요')
    .setContexts(InteractionContextType.Guild),

  admin(
    new SlashCommandBuilder()
      .setName('패널')
      .setDescription('이 채널에 자판기 패널(구매/충전 버튼)을 설치해요 (관리자)')
      .addStringOption((o) => o.setName('제목').setDescription('패널 제목').setMaxLength(80))
      .addStringOption((o) => o.setName('설명').setDescription('패널 설명').setMaxLength(500)),
  ),
  admin(
    new SlashCommandBuilder()
      .setName('상품추가')
      .setDescription('상품을 만들어요 (관리자)')
      .addStringOption((o) => o.setName('이름').setDescription('상품 이름').setRequired(true).setMaxLength(80))
      .addIntegerOption((o) => o.setName('가격').setDescription('가격').setRequired(true).setMinValue(0))
      .addStringOption((o) =>
        o
          .setName('종류')
          .setDescription('지급 방식')
          .setRequired(true)
          .addChoices(
            { name: '재고형 (구매 1번에 재고 1줄씩 자동 지급)', value: 'stock' },
            { name: '역할형 (구매 시 역할 지급, 재고 무제한)', value: 'role' },
          ),
      )
      .addRoleOption((o) => o.setName('역할').setDescription('역할형일 때 지급할 역할'))
      .addStringOption((o) => o.setName('설명').setDescription('상품 설명').setMaxLength(100)),
  ),
  admin(
    new SlashCommandBuilder()
      .setName('재고추가')
      .setDescription('재고형 상품에 재고를 넣어요 (관리자)')
      .addIntegerOption((o) => o.setName('번호').setDescription('상품 번호').setRequired(true)),
  ),
  admin(
    new SlashCommandBuilder()
      .setName('상품삭제')
      .setDescription('상품을 삭제해요 (관리자)')
      .addIntegerOption((o) => o.setName('번호').setDescription('상품 번호').setRequired(true)),
  ),
  admin(
    new SlashCommandBuilder()
      .setName('가격변경')
      .setDescription('상품 가격을 바꿔요 (관리자)')
      .addIntegerOption((o) => o.setName('번호').setDescription('상품 번호').setRequired(true))
      .addIntegerOption((o) => o.setName('가격').setDescription('새 가격').setRequired(true).setMinValue(0)),
  ),
  admin(new SlashCommandBuilder().setName('상품목록').setDescription('상품 번호/재고를 확인해요 (관리자)')),
  admin(
    new SlashCommandBuilder()
      .setName('잔액지급')
      .setDescription('유저 잔액을 직접 올리거나 내려요 (관리자, 음수면 회수)')
      .addUserOption((o) => o.setName('유저').setDescription('대상').setRequired(true))
      .addIntegerOption((o) => o.setName('금액').setDescription('금액').setRequired(true)),
  ),
  admin(
    new SlashCommandBuilder()
      .setName('채널설정')
      .setDescription('충전 요청 / 구매 로그가 올라갈 채널을 정해요 (관리자)')
      .addStringOption((o) =>
        o
          .setName('종류')
          .setDescription('어떤 채널인가요?')
          .setRequired(true)
          .addChoices({ name: '충전 요청 (관리자 승인용)', value: 'chargeChannel' }, { name: '구매 로그', value: 'logChannel' }),
      )
      .addChannelOption((o) =>
        o.setName('채널').setDescription('텍스트 채널').setRequired(true).addChannelTypes(ChannelType.GuildText),
      ),
  ),
  admin(
    new SlashCommandBuilder()
      .setName('계좌설정')
      .setDescription('충전 시 유저에게 보여줄 입금 안내를 설정해요 (관리자)')
      .addStringOption((o) =>
        o.setName('안내').setDescription('예) 국민 123456-78-901234 홍길동').setRequired(true).setMaxLength(500),
      ),
  ),
].map((c) => c.toJSON());

async function registerCommands() {
  const rest = new REST({ version: '10' }).setToken(TOKEN);
  const route = GUILD_ID
    ? Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID)
    : Routes.applicationCommands(CLIENT_ID);
  await rest.put(route, { body: commands });
  console.log(`✅ 슬래시 명령어 ${commands.length}개 등록 완료 (${GUILD_ID ? '서버 전용' : '전역'})`);
}

/* ------------------------------ 봇 / 헬퍼 ------------------------------ */
const client = new Client({ intents: [GatewayIntentBits.Guilds] });

const isAdmin = (i) => i.memberPermissions?.has(ADMIN);
const say = (i, content) => i.reply({ content, flags: EPHEMERAL });

async function sendToChannel(settingKey, payload) {
  const id = db.settings[settingKey];
  if (!id) return null;
  try {
    const ch = await client.channels.fetch(id);
    return await ch.send(payload);
  } catch (e) {
    console.error(`채널(${settingKey}) 전송 실패:`, e.message);
    return null;
  }
}

function panelMessage(title, desc) {
  const embed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle(title || '🛒 자동 판매 자판기')
    .setDescription(desc || '아래 버튼으로 **충전**하고 **구매**하세요.\n구매 즉시 자동으로 지급돼요!');
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('shop_buy').setLabel('구매하기').setEmoji('🛒').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('shop_charge').setLabel('충전하기').setEmoji('💰').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('shop_info').setLabel('내 정보').setEmoji('👤').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('shop_history').setLabel('구매내역').setEmoji('📜').setStyle(ButtonStyle.Secondary),
  );
  return { embeds: [embed], components: [row] };
}

function infoEmbed(user, discordUser) {
  return new EmbedBuilder()
    .setColor(0x57f287)
    .setTitle(`👤 ${discordUser.username} 님의 정보`)
    .addFields(
      { name: '💰 잔액', value: money(user.balance), inline: true },
      { name: '🛍️ 누적 구매', value: `${fmt(user.history.length)}건 / ${money(user.totalSpent)}`, inline: true },
      { name: '📥 누적 충전', value: money(user.totalCharged), inline: true },
    );
}

function chargeEmbed(c, statusText, color) {
  return new EmbedBuilder()
    .setColor(color)
    .setTitle(`💰 충전 요청 #${c.id}`)
    .addFields(
      { name: '신청자', value: `<@${c.userId}>`, inline: true },
      { name: '입금자명', value: c.depositor, inline: true },
      { name: '금액', value: money(c.amount), inline: true },
      { name: '상태', value: statusText },
    )
    .setTimestamp(c.at);
}

/* ------------------------------ 구매 처리 ------------------------------ */
// 잔액/재고를 동기적으로 먼저 차감(선점)하고, 역할 지급 실패 시에만 환불해요.
// → 동시에 여러 명이 눌러도 같은 재고가 두 번 나가지 않아요.
async function purchase(interaction, itemId) {
  const item = db.items[itemId];
  if (!item) return { ok: false, msg: '이미 사라진 상품이에요.' };

  const user = getUser(interaction.user.id);
  if (item.type === 'stock' && item.lines.length === 0) return { ok: false, msg: '품절이에요 😢' };
  if (item.type === 'role' && interaction.member?.roles?.cache?.has(item.roleId)) {
    return { ok: false, msg: '이미 가지고 있는 역할이에요. (결제되지 않았어요)' };
  }
  if (user.balance < item.price) {
    return { ok: false, msg: `잔액이 부족해요. (필요 ${money(item.price)} / 보유 ${money(user.balance)})\n**💰 충전하기** 버튼으로 충전해주세요.` };
  }

  // 선점
  user.balance -= item.price;
  let delivered;
  if (item.type === 'stock') delivered = item.lines.shift();
  save();

  if (item.type === 'role') {
    try {
      const member = await interaction.guild.members.fetch(interaction.user.id);
      await member.roles.add(item.roleId, '자판기 구매');
      delivered = `<@&${item.roleId}> 역할이 지급되었어요.`;
    } catch (err) {
      user.balance += item.price; // 환불
      save();
      console.error('역할 지급 실패:', err);
      return { ok: false, msg: '역할을 지급하지 못했어요. (결제는 취소됐어요)\n관리자에게 봇 역할 순서를 확인해달라고 해주세요.' };
    }
  }

  user.totalSpent += item.price;
  user.history.push({ name: item.name, price: item.price, content: delivered, at: Date.now() });
  if (user.history.length > 100) user.history.shift();
  save();

  // 구매 로그 (지급 내용은 로그에 남기지 않아요)
  sendToChannel('logChannel', {
    embeds: [
      new EmbedBuilder()
        .setColor(0x5865f2)
        .setTitle('🛍️ 구매 로그')
        .addFields(
          { name: '구매자', value: `<@${interaction.user.id}>`, inline: true },
          { name: '상품', value: `#${item.id} ${item.name}`, inline: true },
          { name: '가격', value: money(item.price), inline: true },
          { name: '남은 재고', value: stockText(item), inline: true },
        )
        .setTimestamp(),
    ],
  });

  return { ok: true, item, delivered, balance: user.balance };
}

/* ------------------------------ 이벤트 ------------------------------ */
client.once('clientReady', async () => {
  console.log(`🤖 ${client.user.tag} 로그인 완료`);
  try {
    await registerCommands();
  } catch (e) {
    console.error('명령어 등록 실패:', e);
  }
});

client.on('interactionCreate', async (interaction) => {
  try {
    /* ================= 슬래시 명령어 ================= */
    if (interaction.isChatInputCommand()) {
      const name = interaction.commandName;

      if (name === '내정보') {
        return interaction.reply({ embeds: [infoEmbed(getUser(interaction.user.id), interaction.user)], flags: EPHEMERAL });
      }

      // 이하 관리자 전용
      if (!isAdmin(interaction)) return say(interaction, '관리자만 쓸 수 있어요.');

      switch (name) {
        case '패널': {
          await interaction.channel.send(
            panelMessage(interaction.options.getString('제목'), interaction.options.getString('설명')),
          );
          return say(interaction, '✅ 자판기 패널을 설치했어요!');
        }

        case '상품추가': {
          const type = interaction.options.getString('종류');
          const role = interaction.options.getRole('역할');
          if (type === 'role') {
            if (!role) return say(interaction, '역할형 상품은 `역할` 을 꼭 선택해주세요.');
            if (role.managed || role.id === interaction.guild.id) {
              return say(interaction, '이 역할은 지급할 수 없어요. (@everyone 또는 봇 전용 역할)');
            }
          }
          const id = db.nextId++;
          db.items[id] = {
            id,
            name: interaction.options.getString('이름'),
            price: interaction.options.getInteger('가격'),
            type,
            roleId: type === 'role' ? role.id : null,
            lines: [],
            description: interaction.options.getString('설명') ?? '',
          };
          save();
          const next = type === 'stock' ? `\n이제 \`/재고추가 번호:${id}\` 로 재고를 넣어주세요.` : '';
          return say(interaction, `✅ 상품 **#${id} ${db.items[id].name}** 을(를) 만들었어요!${next}`);
        }

        case '재고추가': {
          const id = interaction.options.getInteger('번호');
          const item = db.items[id];
          if (!item) return say(interaction, '그런 번호의 상품이 없어요.');
          if (item.type !== 'stock') return say(interaction, '역할형 상품은 재고가 필요 없어요.');
          const modal = new ModalBuilder()
            .setCustomId(`stock_modal:${id}`)
            .setTitle(`#${id} 재고 추가`)
            .addComponents(
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('lines')
                  .setLabel('재고 (한 줄에 1개씩)')
                  .setStyle(TextInputStyle.Paragraph)
                  .setPlaceholder('아이디:비밀번호\n쿠폰코드\n...')
                  .setRequired(true)
                  .setMaxLength(4000),
              ),
            );
          return interaction.showModal(modal);
        }

        case '상품삭제': {
          const id = interaction.options.getInteger('번호');
          if (!db.items[id]) return say(interaction, '그런 번호의 상품이 없어요.');
          const { name: n, lines } = db.items[id];
          delete db.items[id];
          save();
          return say(interaction, `🗑️ **#${id} ${n}** 삭제 완료! (남아있던 재고 ${lines.length}개도 함께 삭제됐어요)`);
        }

        case '가격변경': {
          const id = interaction.options.getInteger('번호');
          if (!db.items[id]) return say(interaction, '그런 번호의 상품이 없어요.');
          db.items[id].price = interaction.options.getInteger('가격');
          save();
          return say(interaction, `✅ **#${id} ${db.items[id].name}** 가격: ${money(db.items[id].price)}`);
        }

        case '상품목록': {
          const items = Object.values(db.items).sort((a, b) => a.id - b.id);
          if (!items.length) return say(interaction, '등록된 상품이 없어요.');
          const text = items
            .map((it) => `**#${it.id}** ${it.name} — ${money(it.price)} · ${it.type === 'role' ? '역할형' : '재고형'} · 재고 ${stockText(it)}`)
            .join('\n');
          return interaction.reply({
            embeds: [new EmbedBuilder().setColor(0xfee75c).setTitle('📋 상품 목록').setDescription(text.slice(0, 4000))],
            flags: EPHEMERAL,
          });
        }

        case '잔액지급': {
          const target = interaction.options.getUser('유저');
          const u = getUser(target.id);
          u.balance = Math.max(0, u.balance + interaction.options.getInteger('금액'));
          save();
          return say(interaction, `💸 ${target} 님 잔액: **${money(u.balance)}**`);
        }

        case '채널설정': {
          const key = interaction.options.getString('종류');
          const ch = interaction.options.getChannel('채널');
          try {
            await ch.send('✅ 자판기봇이 이 채널에 연결되었어요.');
          } catch {
            return say(interaction, `${ch} 채널에 메시지를 보낼 수 없어요. 봇의 채널 권한을 확인해주세요.`);
          }
          db.settings[key] = ch.id;
          save();
          return say(interaction, `✅ ${key === 'chargeChannel' ? '충전 요청' : '구매 로그'} 채널을 ${ch} 으로 설정했어요.`);
        }

        case '계좌설정': {
          db.settings.bank = interaction.options.getString('안내');
          save();
          return say(interaction, `✅ 입금 안내를 저장했어요:\n${db.settings.bank}`);
        }
      }
      return;
    }

    /* ================= 모달 제출 ================= */
    if (interaction.isModalSubmit()) {
      // 재고 추가
      if (interaction.customId.startsWith('stock_modal:')) {
        if (!isAdmin(interaction)) return say(interaction, '관리자만 쓸 수 있어요.');
        const item = db.items[interaction.customId.split(':')[1]];
        if (!item) return say(interaction, '이미 사라진 상품이에요.');
        const lines = interaction.fields
          .getTextInputValue('lines')
          .split('\n')
          .map((s) => s.trim())
          .filter(Boolean);
        item.lines.push(...lines);
        save();
        return say(interaction, `📦 **#${item.id} ${item.name}** 재고 **${lines.length}개** 추가! (현재 ${item.lines.length}개)`);
      }

      // 충전 신청
      if (interaction.customId === 'charge_modal') {
        const depositor = interaction.fields.getTextInputValue('depositor').trim();
        const amount = Number(interaction.fields.getTextInputValue('amount').replace(/[^0-9]/g, ''));
        if (!amount || amount < MIN_CHARGE) return say(interaction, `최소 충전 금액은 ${money(MIN_CHARGE)} 이에요.`);
        if (amount > MAX_CHARGE) return say(interaction, `한 번에 ${money(MAX_CHARGE)} 까지만 신청할 수 있어요.`);

        const pending = Object.values(db.charges).filter((c) => c.userId === interaction.user.id && c.status === 'pending');
        if (pending.length >= MAX_PENDING) {
          return say(interaction, `처리 대기 중인 충전 요청이 ${MAX_PENDING}건이에요. 승인될 때까지 기다려주세요.`);
        }

        const id = db.nextChargeId++;
        const c = { id, userId: interaction.user.id, depositor, amount, status: 'pending', at: Date.now() };
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`charge_ok:${id}`).setLabel('승인').setStyle(ButtonStyle.Success),
          new ButtonBuilder().setCustomId(`charge_no:${id}`).setLabel('거절').setStyle(ButtonStyle.Danger),
        );
        const sent = await sendToChannel('chargeChannel', { embeds: [chargeEmbed(c, '⏳ 승인 대기', 0xfee75c)], components: [row] });
        if (!sent) return say(interaction, '충전 요청을 전달하지 못했어요. 관리자에게 문의해주세요.');

        db.charges[id] = c;
        save();
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor(0xfee75c)
              .setTitle('💰 충전 신청 완료')
              .setDescription(
                `아래 계좌로 **입금자명 \`${depositor}\`** 으로 **${money(amount)}** 을 입금해주세요.\n입금이 확인되면 관리자가 승인하고, 잔액이 충전돼요.\n\n${db.settings.bank}`,
              ),
          ],
          flags: EPHEMERAL,
        });
      }
      return;
    }

    /* ================= 셀렉트 메뉴 ================= */
    if (interaction.isStringSelectMenu() && interaction.customId === 'shop_select') {
      const item = db.items[interaction.values[0]];
      if (!item) return interaction.update({ content: '이미 사라진 상품이에요.', embeds: [], components: [] });
      const u = getUser(interaction.user.id);

      const embed = new EmbedBuilder()
        .setColor(0xfee75c)
        .setTitle(`#${item.id} ${item.name}`)
        .setDescription(item.description || '설명이 없어요.')
        .addFields(
          { name: '가격', value: money(item.price), inline: true },
          { name: '재고', value: stockText(item), inline: true },
          { name: '내 잔액', value: money(u.balance), inline: true },
        );
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`shop_confirm:${item.id}`)
          .setLabel('구매 확정')
          .setStyle(ButtonStyle.Success)
          .setDisabled(remaining(item) === 0),
        new ButtonBuilder().setCustomId('shop_cancel').setLabel('취소').setStyle(ButtonStyle.Secondary),
      );
      return interaction.update({ content: '', embeds: [embed], components: [row] });
    }

    /* ================= 버튼 ================= */
    if (interaction.isButton()) {
      const id = interaction.customId;

      if (id === 'shop_buy') {
        const items = Object.values(db.items).sort((a, b) => a.id - b.id);
        if (!items.length) return say(interaction, '아직 등록된 상품이 없어요.');
        const embed = new EmbedBuilder()
          .setColor(0x5865f2)
          .setTitle('🛒 상품 목록')
          .setDescription(
            items
              .map((it) => `**#${it.id} ${it.name}** — ${money(it.price)} · 재고 ${stockText(it)}${it.description ? `\n└ ${it.description}` : ''}`)
              .join('\n\n')
              .slice(0, 4000),
          )
          .setFooter({ text: '구매할 상품을 골라주세요' });
        const menu = new StringSelectMenuBuilder()
          .setCustomId('shop_select')
          .setPlaceholder('상품을 선택하세요')
          .addOptions(
            items.slice(0, 25).map((it) => ({
              label: `#${it.id} ${it.name}`.slice(0, 100),
              description: `${money(it.price)} · ${stockText(it)}`.slice(0, 100),
              value: String(it.id),
            })),
          );
        return interaction.reply({ embeds: [embed], components: [new ActionRowBuilder().addComponents(menu)], flags: EPHEMERAL });
      }

      if (id === 'shop_cancel') {
        return interaction.update({ content: '취소했어요.', embeds: [], components: [] });
      }

      if (id.startsWith('shop_confirm:')) {
        await interaction.deferUpdate();
        const r = await purchase(interaction, id.split(':')[1]);
        if (!r.ok) return interaction.editReply({ content: `❌ ${r.msg}`, embeds: [], components: [] });

        const safe = String(r.delivered).replace(/```/g, "'''");
        const body = r.item.type === 'stock' ? `**${r.item.name}**\n\`\`\`\n${safe}\n\`\`\`` : `**${r.item.name}**\n${r.delivered}`;
        const embed = new EmbedBuilder()
          .setColor(0x57f287)
          .setTitle('🎉 구매 완료!')
          .setDescription(body)
          .setFooter({ text: `남은 잔액 ${money(r.balance)} · 구매내역 버튼에서 다시 볼 수 있어요` });

        let dm = true;
        try {
          await interaction.user.send({ embeds: [embed] });
        } catch {
          dm = false;
        }
        if (!dm) embed.setFooter({ text: `남은 잔액 ${money(r.balance)} · DM이 막혀 있어요! 이 화면을 꼭 저장해두세요` });
        return interaction.editReply({ content: '', embeds: [embed], components: [] });
      }

      if (id === 'shop_charge') {
        if (!db.settings.bank) return say(interaction, '아직 입금 계좌가 설정되지 않았어요. 관리자에게 문의해주세요.');
        if (!db.settings.chargeChannel) return say(interaction, '아직 충전 채널이 설정되지 않았어요. 관리자에게 문의해주세요.');
        const modal = new ModalBuilder()
          .setCustomId('charge_modal')
          .setTitle('충전 신청')
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder().setCustomId('depositor').setLabel('입금자명').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(20),
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('amount')
                .setLabel(`충전 금액 (최소 ${fmt(MIN_CHARGE)}${CURRENCY})`)
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('10000')
                .setRequired(true)
                .setMaxLength(9),
            ),
          );
        return interaction.showModal(modal);
      }

      if (id === 'shop_info') {
        return interaction.reply({ embeds: [infoEmbed(getUser(interaction.user.id), interaction.user)], flags: EPHEMERAL });
      }

      if (id === 'shop_history') {
        const h = getUser(interaction.user.id).history.slice(-10).reverse();
        if (!h.length) return say(interaction, '아직 구매한 상품이 없어요.');
        const text = h
          .map((x) => `**${x.name}** (${money(x.price)}) <t:${Math.floor(x.at / 1000)}:R>\n\`\`\`\n${String(x.content).slice(0, 300).replace(/```/g, "'''")}\n\`\`\``)
          .join('\n');
        return interaction.reply({
          embeds: [new EmbedBuilder().setColor(0x57f287).setTitle('📜 최근 구매내역 (10건)').setDescription(text.slice(0, 4000))],
          flags: EPHEMERAL,
        });
      }

      // 충전 승인 / 거절 (관리자)
      if (id.startsWith('charge_ok:') || id.startsWith('charge_no:')) {
        if (!isAdmin(interaction)) return say(interaction, '관리자만 처리할 수 있어요.');
        const c = db.charges[id.split(':')[1]];
        if (!c || c.status !== 'pending') return say(interaction, '이미 처리됐거나 없는 요청이에요.');

        const approve = id.startsWith('charge_ok:');
        c.status = approve ? 'approved' : 'rejected';
        c.by = interaction.user.id;
        if (approve) {
          const u = getUser(c.userId);
          u.balance += c.amount;
          u.totalCharged += c.amount;
        }
        save();

        await interaction.update({
          embeds: [
            chargeEmbed(
              c,
              approve ? `✅ 승인됨 (by ${interaction.user.username})` : `❌ 거절됨 (by ${interaction.user.username})`,
              approve ? 0x57f287 : 0xed4245,
            ),
          ],
          components: [],
        });

        try {
          const target = await client.users.fetch(c.userId);
          await target.send(
            approve
              ? `✅ 충전 요청 #${c.id} 이(가) 승인되어 **${money(c.amount)}** 이(가) 충전됐어요! (현재 ${money(db.users[c.userId].balance)})`
              : `❌ 충전 요청 #${c.id} 이(가) 거절됐어요. 입금 내역을 확인하고 관리자에게 문의해주세요.`,
          );
        } catch {}
        return;
      }
    }
  } catch (err) {
    console.error('인터랙션 처리 중 오류:', err);
    const msg = '앗, 오류가 났어요. 잠시 후 다시 시도해주세요 🙏';
    try {
      if (interaction.deferred || interaction.replied) await interaction.followUp({ content: msg, flags: EPHEMERAL });
      else await interaction.reply({ content: msg, flags: EPHEMERAL });
    } catch {}
  }
});

client.login(TOKEN);
